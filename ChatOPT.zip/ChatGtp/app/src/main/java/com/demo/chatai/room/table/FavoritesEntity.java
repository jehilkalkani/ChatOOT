package com.demo.chatai.room.table;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;


@Entity(tableName = "favorites")
public class FavoritesEntity implements Serializable {

    @ColumnInfo(name = "answers")
    public String answers;

    @ColumnInfo(name = "questions")
    public String questions;


    @PrimaryKey()
    @NonNull
    public Long id;


    public FavoritesEntity(String answers, String questions, @NonNull Long id) {
        this.answers = answers;
        this.questions = questions;
        this.id = id;
    }

    public String getAnswers() {
        return answers;
    }

    public void setAnswers(String answers) {
        this.answers = answers;
    }

    public String getQuestions() {
        return questions;
    }

    public void setQuestions(String questions) {
        this.questions = questions;
    }

    @NonNull
    public Long getId() {
        return id;
    }

    public void setId(@NonNull Long id) {
        this.id = id;
    }
}
