package com.demo.chatai.room;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.demo.chatai.room.table.ApiKeyEntity;
import com.demo.chatai.room.table.ChatEntity;
import com.demo.chatai.room.table.ConversationEntity;
import com.demo.chatai.room.table.FavoritesEntity;

import java.util.List;


@Dao
public interface DAO {

    @Query("DELETE FROM api_key")
    void deleteAllApiKey();


    @Query("DELETE FROM chat")
    void deleteAllChat();


    @Query("DELETE FROM conversation")
    void deleteAllConversation();

    @Query("DELETE FROM api_key WHERE id = :id")
    void deleteApiKey(long id);

    @Query("DELETE FROM chat WHERE id = :id")
    void deleteChat(long id);

    @Query("DELETE FROM conversation WHERE id = :id")
    void deleteConversation(long id);

    @Query("SELECT * FROM api_key ORDER BY id DESC")
    List<ApiKeyEntity> getAllApiKey();


    @Query("SELECT * FROM conversation ORDER BY id DESC")
    List<ConversationEntity> getAllConversation();

    @Query("SELECT * FROM api_key WHERE id = :id LIMIT 1")
    ApiKeyEntity getApiKey(long id);

    @Query("SELECT COUNT(id) FROM api_key")
    Integer getApiKeyCount();

    @Query("SELECT COUNT(id) FROM api_key WHERE selected = 1")
    Integer getApiKeyEnabledCount();

    @Query("SELECT key FROM api_key ORDER BY RANDOM() LIMIT 1")
    String getApiKeyRandom();

    @Query("SELECT * FROM chat WHERE :id = :id LIMIT 1")
    ChatEntity getChat(long id);

    @Query("SELECT * FROM chat WHERE conversation = :conversation ORDER BY id ASC")
    List<ChatEntity> getChatByConversation(long conversation);

    @Query("SELECT * FROM chat ORDER BY created_at DESC LIMIT :limit OFFSET :offset")
    List<ChatEntity> getChatByPage(int limit, int offset);

    @Query("SELECT COUNT(id) FROM chat")
    Integer getChatCount();

    @Query("SELECT COUNT(id) FROM chat WHERE conversation = :conversation")
    Integer getChatCountByConversation(long conversation);

    @Query("SELECT * FROM conversation WHERE id = :id LIMIT 1")
    ConversationEntity getConversation(long id);


    @Query("SELECT COUNT(id) FROM conversation")
    Integer getConversationCount();

    @Query("SELECT `key` FROM api_key WHERE selected LIMIT 1")
    String getSelectedApiKey();

    @Insert
    void insertApiKey(ApiKeyEntity apiKey);

    @Insert
    void insertChat(ChatEntity chat);


    @Insert(onConflict = OnConflictStrategy.REPLACE)

    void insertConversation(ConversationEntity conversation);


    @Query("UPDATE api_key SET selected = 0 WHERE id > 0")
    void resetSelected();


    @Query("SELECT * FROM favorites")
    List<FavoritesEntity> getAllFavoritesEntity();

    @Insert
    void insertFavoritesEntity(FavoritesEntity favorites);

    @Query("DELETE FROM favorites WHERE id = :id")
    void deleteFavoritesEntity(long id);


    @Query("SELECT COUNT(id) FROM favorites WHERE id = :id")
    Integer isFavoritesFound(long id);
}
