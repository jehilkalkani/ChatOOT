package com.demo.chatai.room.table;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;


@Entity(tableName = "conversation")
public class ConversationEntity implements Serializable {

    @PrimaryKey
    @NonNull
    public Long id;
    @ColumnInfo(name = "name")
    public String name = "";
    @ColumnInfo(name = "history_message")
    public String history_message = "";

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHistory_message() {
        return this.history_message;
    }

    public void setHistory_message(String history_message) {
        this.history_message = history_message;
    }
}
