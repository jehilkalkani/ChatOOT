package com.demo.chatai.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.demo.chatai.databinding.ItemConversationBinding;
import com.demo.chatai.room.table.ConversationEntity;

import java.util.ArrayList;
import java.util.List;


public class AdapterConversation extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context ctx;
    private List<ConversationEntity> items;
    private OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {
        void onItemClick(View view, ConversationEntity obj, int position);

        void onItemLongClick(View view, ConversationEntity obj, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mOnItemClickListener = mItemClickListener;
    }

    public AdapterConversation(Context context, RecyclerView view, List<ConversationEntity> items) {
        new ArrayList();
        this.items = items;
        this.ctx = context;

    }

    public class OriginalViewHolder extends RecyclerView.ViewHolder {
        ItemConversationBinding binding;

        public OriginalViewHolder(ItemConversationBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new OriginalViewHolder(ItemConversationBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof OriginalViewHolder) {
            final ConversationEntity conversationEntity = this.items.get(position);
            OriginalViewHolder originalViewHolder = (OriginalViewHolder) holder;
            originalViewHolder.binding.name.setText(conversationEntity.name);
            originalViewHolder.binding.lytParent.setOnClickListener(new View.OnClickListener() {
                @Override
                public final void onClick(View view) {
                    if (mOnItemClickListener != null) {
                        mOnItemClickListener.onItemClick(view, conversationEntity, position);
                    }
                }
            });
            originalViewHolder.binding.lytParent.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public final boolean onLongClick(View view) {
                    return AdapterConversation.this.m88x4d196171(conversationEntity, position, view);
                }
            });
        }
    }

    public boolean m88x4d196171(ConversationEntity conversationEntity, int i, View view) {
        OnItemClickListener onItemClickListener = this.mOnItemClickListener;
        if (onItemClickListener != null) {
            onItemClickListener.onItemLongClick(view, conversationEntity, i);
            return true;
        }
        return true;
    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }

    public void removeItem(int position) {
        this.items.remove(position);
        notifyDataSetChanged();
    }

    public void addData(ConversationEntity item) {
        this.items.add(0, item);
        notifyItemInserted(0);
    }

    public void insertData(List<ConversationEntity> items) {
        int itemCount = getItemCount();
        int size = items.size();
        this.items.addAll(items);
        notifyItemRangeInserted(itemCount, size);
    }

    public void setItems(List<ConversationEntity> items) {
        this.items = items;
        notifyDataSetChanged();
    }
}
