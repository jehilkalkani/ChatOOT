package com.demo.chatai.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.viewpager.widget.PagerAdapter;

import com.demo.chatai.R;


public class IntroOneAdapter extends PagerAdapter {
    Context coxt;
    int[] intro_img = {R.drawable.intro1, R.drawable.intro2, R.drawable.intro3};
    public IntroOneAdapter(Context context) {
        this.coxt = context;
    }

    @Override 
    public int getCount() {
        return this.intro_img.length;
    }

    @Override 
    public boolean isViewFromObject(View view, Object obj) {
        return view == ((LinearLayout) obj);
    }

    @Override 
    public Object instantiateItem(ViewGroup viewGroup, int i) {
        View inflate = ((LayoutInflater) this.coxt.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.view_layout, viewGroup, false);
        ((ImageView) inflate.findViewById(R.id.image_view)).setImageResource(this.intro_img[i]);
        viewGroup.addView(inflate);
        return inflate;
    }


    @Override 
    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        viewGroup.removeView((LinearLayout) obj);
    }
}
