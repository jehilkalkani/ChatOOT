package com.demo.chatai.connection.response;

import com.demo.chatai.model.Chat;

import java.io.Serializable;
import java.util.List;


public class ResponseChat implements Serializable {
    public List<Choice> choices;
    public Usage usage;
    public String id = "";
    public String object = "";
    public int created = 0;
    public String model = "";

    
    public class Choice {
        public String finish_reason;
        public int index;
        public Chat message;

        public Choice() {
        }
    }

    
    public class Usage {
        public int completion_tokens;
        public int prompt_tokens;
        public int total_tokens;

        public Usage() {
        }
    }

}
