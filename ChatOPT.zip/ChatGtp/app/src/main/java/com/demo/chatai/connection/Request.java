package com.demo.chatai.connection;

import android.text.TextUtils;

import com.demo.chatai.AppConfig;
import com.demo.chatai.connection.response.ResponseChat;
import com.demo.chatai.connection.response.ResponseError;
import com.demo.chatai.ThisApp;
import com.demo.chatai.model.Chat;
import com.demo.chatai.model.Param;
import com.google.gson.Gson;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class Request {
    public static Call sendChat(List<Chat> messages, final RequestListener<ResponseChat> listener) {
        API createAPI = RestAdapter.createAPI();
        Param param = new Param();
        param.model = AppConfig.general.param_open_ai_model;
        param.messages = messages;
        param.temperature = AppConfig.general.param_temperature.doubleValue();
        param.max_tokens = AppConfig.general.param_max_tokens.intValue();
        param.top_p = 1;
        param.frequency_penalty = 0.0d;
        param.presence_penalty = 0.6d;
        String selectedApiKey = ThisApp.dao().getSelectedApiKey();
        if (ThisApp.pref().isRandomKey() || TextUtils.isEmpty(selectedApiKey)) {
            selectedApiKey = ThisApp.dao().getApiKeyRandom();
        }
        if (TextUtils.isEmpty(selectedApiKey)) {
            listener.onFailed("API_KEY", null);
            return null;
        }
        Call<ResponseChat> sendChat = createAPI.sendChat(AppConfig.general.api_url, param, "Bearer " + selectedApiKey);
        sendChat.enqueue(new Callback<ResponseChat>() { 
            @Override 
            public void onResponse(Call<ResponseChat> call, Response<ResponseChat> response) {
                ResponseChat body = response.body();
                listener.onFinish();
                if (body == null || body.choices == null || body.choices.isEmpty()) {
                    listener.onFailed(null, response.errorBody() != null ? (ResponseError) new Gson().fromJson(response.errorBody().charStream(), ResponseError.class) : null);
                } else {
                    listener.onSuccess(body);
                }
            }

            @Override 
            public void onFailure(Call<ResponseChat> call, Throwable t) {
                listener.onFinish();
                listener.onFailed(t.getMessage(), null);
            }
        });
        return sendChat;
    }
}