package com.demo.chatai.splash;
import static com.demo.chatai.ThisApp.REQUIRED_PERMISSIONS;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.demo.chatai.R;
import com.demo.chatai.ThisApp;
import com.demo.chatai.activity.ActivityMain;

public class SplashScreen extends AppCompatActivity {
    private SharedPreferences sharedPreferences;
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.activity_splash);
        getWindow().getDecorView().setSystemUiVisibility(8192);
        if (isOnline(this)) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    OpenNext1();
                }
            },5000);
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Network error…").setMessage("Internet is not available, reconnect network and try again.").setNegativeButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public final void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                    finishAffinity();

                }
            });
            AlertDialog alert = builder.create();
            alert.show();
        }
    }
    public void OpenNext1() {
        if (hasPermissions(this, ThisApp.REQUIRED_PERMISSIONS)) {
            sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
            if (isFirstTime()) {
                Toast.makeText(this, "Welcome to the app!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, SecondActivity.class).putExtra("isFromSplash", "true"));
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("isFirstTime", false);
                editor.apply();
            } else {
                startActivity(new Intent(this, ActivityMain.class));
                finish();
            }
        } else {
            startActivity(new Intent(this, PermissionGrant_Activity.class));
            finish();
        }
    }
    private static boolean hasPermissions(Context context, String... permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.checkSelfPermission(context, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }
    private boolean isFirstTime() {
        return sharedPreferences.getBoolean("isFirstTime", true);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        ExitApp();
    }
    public void ExitApp() {
        moveTaskToBack(true);
        finish();
        Process.killProcess(Process.myPid());
        System.exit(0);
    }
    public static boolean isOnline(Context cont) {
        ConnectivityManager cm = (ConnectivityManager) cont.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }
}
