package com.demo.chatai.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.chatai.AdAdmob;
import com.demo.chatai.adapter.AdapterApiKey;
import com.demo.chatai.ThisApp;
import com.demo.chatai.room.table.ApiKeyEntity;
import com.demo.chatai.utils.GeneralListener;
import com.demo.chatai.utils.Tools;
import com.demo.chatai.R;
import com.demo.chatai.databinding.ActivityApiKeyBinding;

import java.util.ArrayList;
import java.util.List;

public class ActivityApiKey extends AppCompatActivity {
    public AdapterApiKey adapter;
    public ActivityApiKeyBinding binding;

    public static void navigate(Activity activity) {
        activity.startActivity(new Intent(activity, ActivityApiKey.class));
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityApiKeyBinding inflate = ActivityApiKeyBinding.inflate(getLayoutInflater());
        this.binding = inflate;

        AdAdmob adAdmob = new AdAdmob( this);
        adAdmob.BannerAd(binding.banner, this);
        adAdmob.FullscreenAd_Counter(this);


        setContentView(inflate.getRoot());
        initToolbar();
        initComponent();
        Tools.RTLMode(getWindow());
    }

    private void initToolbar() {
        this.binding.toolbar.setNavigationIcon(R.drawable.ic_back);
        this.binding.toolbar.getNavigationIcon().setColorFilter(getResources().getColor(R.color.toolbarIconText), PorterDuff.Mode.SRC_ATOP);
        setSupportActionBar(this.binding.toolbar);
        ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setDisplayHomeAsUpEnabled(true);
        supportActionBar.setHomeButtonEnabled(true);
    }

    private void initComponent() {
        this.binding.recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        this.adapter = new AdapterApiKey(this, this.binding.recyclerView, new ArrayList());
        this.binding.recyclerView.setAdapter(this.adapter);
        this.adapter.setOnItemClickListener(new AdapterApiKey.OnItemClickListener() {
            @Override
            public final void onItemClick(View view, ApiKeyEntity apiKeyEntity, int i, AdapterApiKey.ActionType actionType) {
                ActivityApiKey.this.m56lambda$initComponent$0$comappchattyaiactivityActivityApiKey(view, apiKeyEntity, i, actionType);
            }
        });
        this.binding.buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                ActivityApiKey.this.m57lambda$initComponent$1$comappchattyaiactivityActivityApiKey(view);
            }
        });
        this.binding.buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                ActivityApiKey.this.m58lambda$initComponent$2$comappchattyaiactivityActivityApiKey(view);
            }
        });
        displayData();
    }

    public void m56lambda$initComponent$0$comappchattyaiactivityActivityApiKey(View view, ApiKeyEntity apiKeyEntity, int i, AdapterApiKey.ActionType actionType) {
        if (actionType.equals(AdapterApiKey.ActionType.ITEM)) {
            try {
                this.adapter.refreshSelected();
                ThisApp.dao().resetSelected();
                apiKeyEntity.setSelected(!apiKeyEntity.getSelected());
                List<ApiKeyEntity> allApiKey2 = ThisApp.dao().getAllApiKey();
                boolean isUniqe = true;
                if (!allApiKey2.isEmpty()) {
                    for (int j = 0; j < allApiKey2.size(); j++) {
                        Log.e("MYTAG", "ErrorNo:key:" + allApiKey2.get(j).key);
                        Log.e("MYTAG", "ErrorNo:mykey:" + apiKeyEntity.key);
                        if (!allApiKey2.get(j).key.equals(apiKeyEntity.key)) {
                            Toast.makeText(getApplication(), "API key Already Exists", Toast.LENGTH_LONG);
                            isUniqe = false;
                            break;
                        }
                    }
                }
                if (isUniqe) {
                    ThisApp.dao().insertApiKey(apiKeyEntity);
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getApplication(), "Something Error", Toast.LENGTH_LONG);
                Log.e("MYTAG", "ErrorNo 1212:" + e);
            }
            this.adapter.notifyDataSetChanged();
        } else if (actionType.equals(AdapterApiKey.ActionType.EDIT)) {
            Tools.showDialogApiKey(this, apiKeyEntity, new GeneralListener<ApiKeyEntity>() {
                @Override
                public void onFinish(ApiKeyEntity resp) {
                    super.onFinish(resp);
                    ActivityApiKey.this.displayData();
                }
            });
        }
    }

    public void m57lambda$initComponent$1$comappchattyaiactivityActivityApiKey(View view) {
        Tools.showDialogApiKey(this, null, new GeneralListener<ApiKeyEntity>() {
            @Override
            public void onFinish(ApiKeyEntity resp) {
                super.onFinish(resp);
                ActivityApiKey.this.displayData();
            }
        });
    }

    public void m58lambda$initComponent$2$comappchattyaiactivityActivityApiKey(View view) {
        Tools.showDialogApiKey(this, null, new GeneralListener<ApiKeyEntity>() {
            @Override
            public void onFinish(ApiKeyEntity resp) {
                super.onFinish(resp);
                ActivityApiKey.this.displayData();
            }
        });
    }

    public void displayData() {
        this.adapter.setItems(ThisApp.dao().getAllApiKey());
        showNoItemView(this.adapter.getItemCount() == 0);
    }

    private void showNoItemView(boolean show) {
        ((TextView) findViewById(R.id.failed_subtitle)).setText(getString(R.string.empty_state_no_data));
        this.binding.lytFailed.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 16908332) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
