package com.demo.chatai.connection;

import com.demo.chatai.AppConfig;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RestAdapter {


















    public static API create(boolean receiver) {
        new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(receiver ? 2L : 5L, TimeUnit.SECONDS);
        builder.writeTimeout(receiver ? 5L : 10L, TimeUnit.SECONDS);
        builder.readTimeout(receiver ? 5L : 30L, TimeUnit.SECONDS);
        builder.cache(null);
        OkHttpClient build = builder.build();
        String str = AppConfig.general.api_url;
        if (!str.endsWith("/")) {
            str = str + "/";
        }
        return (API) new Retrofit.Builder().baseUrl(str).addConverterFactory(GsonConverterFactory.create()).client(build).build().create(API.class);
    }
    public static API createAPI() {
        return create(false);
    }
    public static API createAPI(boolean receiver) {
        return create(receiver);
    }

}
