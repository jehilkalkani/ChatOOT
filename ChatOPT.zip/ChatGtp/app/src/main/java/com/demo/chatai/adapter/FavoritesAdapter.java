package com.demo.chatai.adapter;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.chatai.R;
import com.demo.chatai.ThisApp;
import com.demo.chatai.room.table.FavoritesEntity;

import java.util.List;
import java.util.Locale;

public class FavoritesAdapter extends RecyclerView.Adapter<FavoritesAdapter.ViewHolder> {
    private final String TAG = "FavoritesAdapter";
    List<FavoritesEntity> list;
    private TextToSpeech mTTS;
    Context context;

    public FavoritesAdapter(List<FavoritesEntity> list, Context context) {
        this.list = list;
        this.context = context;

        mTTS = new TextToSpeech(context, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    mTTS.setLanguage(Locale.US);
                }
            }
        });
    }

    @NonNull
    @Override
    public FavoritesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.item_favorites, parent, false);
        return new FavoritesAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoritesAdapter.ViewHolder holder, int position) {
        String answers = list.get(position).getAnswers();
        String questions = list.get(position).getQuestions();

        holder.textQuestions.setText(questions);
        holder.textAnswers.setText(answers);
        holder.ttsDelete.setOnClickListener(v -> {
            ThisApp.dao().deleteFavoritesEntity(list.get(position).getId());
            list.remove(position);
            notifyItemRemoved(position);
        });

        holder.copy.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) v.getContext().getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("label", answers);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(v.getContext(), "copy ", Toast.LENGTH_SHORT).show();
        });

        holder.share.setOnClickListener(v -> {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, answers);
            v.getContext().startActivity(Intent.createChooser(shareIntent, "Share this app with"));
        });
        holder.speech.setOnClickListener(v -> {
            mTTS.speak(answers, TextToSpeech.QUEUE_FLUSH, null);
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textQuestions;
        TextView textAnswers;
        ImageView ttsDelete;
        ImageView share;
        ImageView copy;
        ImageView speech;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textQuestions = itemView.findViewById(R.id.text_questions);
            textAnswers = itemView.findViewById(R.id.text_answers);
            ttsDelete = itemView.findViewById(R.id.tts_delete);
            share = itemView.findViewById(R.id.share);
            copy = itemView.findViewById(R.id.copy);
            speech = itemView.findViewById(R.id.tts_speech);
        }
    }
}
