package com.demo.chatai;
import android.Manifest;
import android.app.Application;
import android.content.Context;
import android.location.Location;
import android.os.Build;

import com.demo.chatai.data.SharedPref;
import com.demo.chatai.room.AppDatabase;
import com.demo.chatai.room.DAO;
import com.demo.chatai.utils.Tools;

import java.util.ArrayList;
import java.util.List;
public class ThisApp extends Application {
    public static Context getContext() {
        return mInstance;
    }
    public static final String[] REQUIRED_PERMISSIONS = getRequiredPermissions().toArray(new String[0]);
    private final String TAG = "App";
    public static List<String> getRequiredPermissions() {
        List<String> permissions = new ArrayList<>();
        permissions.add(Manifest.permission.CAMERA);
        permissions.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        return permissions;
    }
    private static DAO dao;
    private static ThisApp mInstance;
    private static SharedPref sharedPref;

    private Location location = null;
    private List<String> categories = new ArrayList();

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        sharedPref = new SharedPref(this);
        dao = AppDatabase.getDb(this).get();
        Tools.applyTheme(pref().isDarkTheme());
    }

    public static synchronized SharedPref pref() {
        SharedPref sharedPref2;
        synchronized (ThisApp.class) {
            sharedPref2 = sharedPref;
        }
        return sharedPref2;
    }
    public static synchronized DAO dao() {
        DAO dao2;
        synchronized (ThisApp.class) {
            dao2 = dao;
        }
        return dao2;
    }
    public static synchronized ThisApp get() {
        ThisApp thisApp;
        synchronized (ThisApp.class) {
            thisApp = mInstance;
        }
        return thisApp;
    }

}
