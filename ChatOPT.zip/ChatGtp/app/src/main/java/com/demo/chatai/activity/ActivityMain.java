package com.demo.chatai.activity;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.chatai.AdAdmob;
import com.demo.chatai.AppConfig;
import com.demo.chatai.R;
import com.demo.chatai.adapter.AdapterChat;
import com.demo.chatai.adapter.AdapterConversation;
import com.demo.chatai.adapter.QuationAdapter;
import com.demo.chatai.connection.Request;
import com.demo.chatai.connection.RequestListener;
import com.demo.chatai.connection.response.ResponseChat;
import com.demo.chatai.connection.response.ResponseError;
import com.demo.chatai.ThisApp;
import com.demo.chatai.databinding.ActivityMainBinding;
import com.demo.chatai.model.Chat;
import com.demo.chatai.room.table.ApiKeyEntity;
import com.demo.chatai.room.table.ChatEntity;
import com.demo.chatai.room.table.ConversationEntity;
import com.demo.chatai.utils.GeneralListener;
import com.demo.chatai.utils.Tools;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class ActivityMain extends AppCompatActivity {
    private ActivityMainBinding binding;
    private ConversationEntity conversation;
    private AdapterChat adapter;
    private AdapterConversation adapterConversation;
    private static ActivityMain instance;
    private TextWatcher mOnTextChangedListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            if (0 < charSequence.length()) {
                binding.mainContent.send.setEnabled(true);
            } else {
                binding.mainContent.send.setEnabled(false);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    public static ActivityMain getInstance() {
        return instance;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        ActivityMainBinding inflate = ActivityMainBinding.inflate(getLayoutInflater());
        this.binding = inflate;


        AdAdmob adAdmob = new AdAdmob( this);
        adAdmob.BannerAd(binding.mainContent.banner, this);
        adAdmob.FullscreenAd_Counter(this);



        setContentView(inflate.getRoot());

        if (getIntent().getStringExtra(AppConfig.strIntentChat) != null) {
            String s = getIntent().getStringExtra(AppConfig.strIntentChat);
            binding.mainContent.message.setText(s);
        }
        initComponent();
        initDrawerLayout();
    }

    private void initComponent() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        linearLayoutManager.setStackFromEnd(true);
        linearLayoutManager.setReverseLayout(false);
        this.binding.toolbarMenuCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showImageDialog();
            }
        });

        this.binding.favoritesList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), FavoritesActivity.class));
            }
        });


        this.binding.mainContent.recyclerView.setLayoutManager(linearLayoutManager);
        this.adapter = new AdapterChat(this, this.binding.mainContent.recyclerView, new ArrayList());

        this.binding.mainContent.recyclerView.setAdapter(this.adapter);
        this.adapter.setOnItemClickListener(new AdapterChat.OnItemClickListener() { 
            @Override 
            public final void onItemClick(View view, ChatEntity chatEntity, int i) {
                dialogChatAction(chatEntity, i);
            }
        });
        this.binding.mainContent.message.addTextChangedListener(mOnTextChangedListener);
        this.binding.mainContent.send.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                sendAction();
            }
        });
        binding.mainContent.mic.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                getSpeechInput();
            }
        });
        this.binding.toolbarMenuMore.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                binding.drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        this.binding.toolbarMenuSetting.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                ActivitySetting.navigate(ActivityMain.this);
            }
        });
        this.binding.toolbarMenuKey.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                ActivityApiKey.navigate(ActivityMain.this);
            }
        });
        if (this.conversation == null || TextUtils.isEmpty(this.conversation.getName())) {
            onNewConversation();
            showNoItemView(this.adapter.getItemCount() == 0);
        }
        if (ThisApp.dao().getApiKeyCount().intValue() <= 0) {
            Tools.showDialogApiKey(this, null, null);
        }
    }

    private void initDrawerLayout() {
        this.binding.lytDrawerMenu.menuDrawerAdd.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                onNewConversation();
            }
        });
        this.binding.lytDrawerMenu.textDrawerAdd.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                onNewConversation();
            }
        });
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        this.binding.lytDrawerMenu.recyclerViewDrawer.setLayoutManager(linearLayoutManager);
        this.adapterConversation = new AdapterConversation(this, this.binding.lytDrawerMenu.recyclerViewDrawer, new ArrayList());
        this.binding.lytDrawerMenu.recyclerViewDrawer.setAdapter(this.adapterConversation);
        this.adapterConversation.setOnItemClickListener(new AdapterConversation.OnItemClickListener() { 
            @Override 
            public void onItemClick(View view, ConversationEntity conversation, int position) {
                onLoading(false);
                ActivityMain.this.binding.drawerLayout.closeDrawer(GravityCompat.START);
                ActivityMain.this.conversation = conversation;
                ActivityMain.this.onConversationSelect();

            }

            @Override 
            public void onItemLongClick(View view, ConversationEntity obj, int position) {
                ActivityMain.this.onConversationSelect();
                ActivityMain.this.dialogDeleteConversation(obj, position);
            }
        });
        this.adapterConversation.setItems(ThisApp.dao().getAllConversation());
    }

    public void dialogDeleteConversation(final ConversationEntity conversation, final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete confirmation");
        builder.setMessage("Are you sure want to delete " + conversation.getName() + " ?");
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() { 
            @Override 
            public final void onClick(DialogInterface dialogInterface, int i) {
                ThisApp.dao().deleteConversation(conversation.getId());
                adapterConversation.removeItem(position);
            }
        });
        builder.setNegativeButton("CANCEL", (DialogInterface.OnClickListener) null);
        builder.create().show();
    }

    public void onConversationSelect() {
        this.binding.title.setText(this.conversation.getName());
        List<ChatEntity> list = ThisApp.dao().getChatByConversation(this.conversation.getId());
        List<ChatEntity> list2 = new ArrayList<>();
        for (ChatEntity chatEntity : list) {
            chatEntity.new_chat = false;
            list2.add(chatEntity);
        }
        this.adapter.setItems(list2);
        showNoItemView(this.adapter.getItemCount() == 0);
    }

    public void dialogChatAction(final ChatEntity chat, final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setItems(new String[]{"Copy text", "Delete chat"}, new DialogInterface.OnClickListener() { 
            @Override 
            public final void onClick(DialogInterface dialogInterface, int i) {
                if (i == 0) {
                    Tools.copyToClipBoard(getApplicationContext(), chat.getMessage());
                } else if (i == 1) {
                    ThisApp.dao().deleteChat(chat.getId().longValue());
                    adapter.removeItem(position);
                }
            }
        });
        builder.create().show();
    }

    private void onNewConversation() {
        ConversationEntity conversationEntity = new ConversationEntity();
        this.conversation = conversationEntity;
        conversationEntity.setId(System.currentTimeMillis());
        this.binding.title.setText("New Chat");
        this.adapter.resetListData();
        this.binding.drawerLayout.closeDrawer(GravityCompat.START);
        showNoItemView(this.adapter.getItemCount() == 0);
    }

    private void showNoItemView(boolean show) {
        ((TextView) findViewById(R.id.failed_subtitle)).setText(getString(R.string.empty_state_no_data));
        if (show) {
            this.binding.mainContent.recyclerView2.setVisibility(View.VISIBLE);
            binding.mainContent.recyclerView.setVisibility(View.GONE);
        } else {
            this.binding.mainContent.recyclerView2.setVisibility(View.GONE);
            binding.mainContent.recyclerView.setVisibility(View.VISIBLE);
        }
    }
    @SuppressLint("ResourceType")
    public void sendAction() {
        final String trim = this.binding.mainContent.message.getText().toString().trim();
        if (TextUtils.isEmpty(trim)) {
            Snackbar.make(findViewById(16908290), (int) R.string.message_cannot_empty, BaseTransientBottomBar.LENGTH_INDEFINITE).show();
            return;
        }
        onLoading(true);
        List<ChatEntity> chatByConversation = ThisApp.dao().getChatByConversation(this.conversation.getId().longValue());
        ArrayList arrayList = new ArrayList();
        for (ChatEntity chatEntity : chatByConversation) {
            arrayList.add(chatEntity.getChat());
        }
        Chat chat = new Chat();
        chat.role = AppConfig.general.role_human;
        chat.content = trim;
        arrayList.add(chat);
        final ChatEntity chatEntity2 = new ChatEntity(trim, this.conversation.getId());
        this.adapter.addData(chatEntity2);
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override 
            public final void run() {
                binding.mainContent.recyclerView.getLayoutManager().scrollToPosition(0);
            }
        }, 500L);
        Request.sendChat(arrayList, new RequestListener<ResponseChat>() { 

            @Override 
            public void onSuccess(ResponseChat resp) {
                super.onSuccess( resp);
                ActivityMain.this.onResponseSuccess(resp, chatEntity2);
                ActivityMain.this.binding.mainContent.recyclerView.getLayoutManager().scrollToPosition(0);
            }
            @Override 
            public void onFailed(String msg, Object error) {
                super.onFailed(msg, error);
                ActivityMain.this.binding.mainContent.message.setText(trim);
                ActivityMain.this.adapter.removeLast();
                if (error instanceof ResponseError) {
                    ActivityMain.this.dialogFailedObject(error);
                } else {
                    ActivityMain.this.dialogFailed(msg);
                }
            }
            @Override 
            public void onFinish() {
                super.onFinish();
                ActivityMain.this.onLoading(false);
            }
        });
    }
    































































    public void dialogFailedObject(Object obj) {
        ResponseError responseError = (ResponseError) obj;
        if (!responseError.error.type.equalsIgnoreCase("insufficient_quota")) {
            dialogFailed(responseError.error.message);
            return;
        }
        final AlertDialog create = new AlertDialog.Builder(this).setTitle(R.string.Failed).setMessage(responseError.error.message).setPositiveButton(R.string.QUOTA, (DialogInterface.OnClickListener) null).setNegativeButton(R.string.UPGRADE, (DialogInterface.OnClickListener) null).setNeutralButton(R.string.CHANGE_KEY, (DialogInterface.OnClickListener) null).create();
        create.setOnShowListener(new DialogInterface.OnShowListener() { 
            @Override 
            public final void onShow(DialogInterface dialogInterface) {
                ActivityMain.this.m70xd2779fb6(create, dialogInterface);
            }
        });
        create.show();
    }

    public  void m70xd2779fb6(AlertDialog alertDialog, DialogInterface dialogInterface) {
        Button button = alertDialog.getButton(-1);
        Button button2 = alertDialog.getButton(-2);
        Button button3 = alertDialog.getButton(-3);
        button.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                Tools.directLinkCustomTab(ActivityMain.this, AppConfig.general.link_quota_usage);

            }
        });
        button2.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                Tools.directLinkCustomTab(ActivityMain.this, AppConfig.general.link_upgrade_account);

            }
        });
        button3.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                ActivityApiKey.navigate(ActivityMain.this);

            }
        });
    }


    public void dialogFailed(String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        boolean z = false;
        if (TextUtils.isEmpty(msg)) {
            msg = "Failed when sending chat..";
        } else if (msg.equals("API_KEY")) {
            msg = "Required set API Key to send chat, please add API Key";
            z = true;
        }
        builder.setMessage(msg);
        boolean finalZ = z;
        builder.setPositiveButton(z ? "CONTINUE" : "RETRY", new DialogInterface.OnClickListener() {
            @Override
            public final void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                if (finalZ) {
                    Tools.showDialogApiKey(ActivityMain.this, null, new GeneralListener<ApiKeyEntity>() {
                        @Override
                        public void onFinish(ApiKeyEntity resp) {
                            super.onFinish(resp);
                            ActivityMain.this.sendAction();
                        }
                    });
                } else {
                    sendAction();
                }

            }
        });
        builder.show();
    }


    public void onLoading(boolean show) {
        if (show) {
            this.binding.mainContent.message.setEnabled(false);
            this.binding.mainContent.send.setEnabled(false);
            this.binding.mainContent.lytInput.setVisibility(View.INVISIBLE);
            this.binding.mainContent.progressLoading.setVisibility(View.VISIBLE);
            return;
        }
        this.binding.mainContent.message.setEnabled(true);
        this.binding.mainContent.send.setEnabled(true);
        this.binding.mainContent.lytInput.setVisibility(View.VISIBLE);
        this.binding.mainContent.progressLoading.setVisibility(View.GONE);
    }

    public void onResponseSuccess(ResponseChat resp, ChatEntity chat_me) {
        boolean z;
        this.binding.mainContent.message.setText("");
        Chat chat = resp.choices.get(0).message;
        ChatEntity chatEntity = new ChatEntity();
        chatEntity.setId(System.currentTimeMillis());
        chatEntity.setMe(false);
        chatEntity.new_chat = true;
        chatEntity.setConversation(this.conversation.getId());
        chatEntity.setMessage(chat.content);
        chatEntity.setCreated_at(chatEntity.getId());
        this.adapter.addData(chatEntity);
        if (ThisApp.dao().getChatCountByConversation(this.conversation.getId()) == 0) {
            String substring = chat_me.getMessage().substring(0, Math.min(chat_me.getMessage().length(), 20));
            this.conversation.setName(substring);
            this.binding.title.setText(substring);
            ThisApp.dao().insertConversation(this.conversation);
            z = true;
        } else {
            z = false;
        }
        ThisApp.dao().insertConversation(this.conversation);
        ThisApp.dao().insertChat(chat_me);
        ThisApp.dao().insertChat(chatEntity);
        if (z) {
            this.adapterConversation.setItems(ThisApp.dao().getAllConversation());
        }
        showNoItemView(this.adapter.getItemCount() == 0);
    }


    public void getSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, 10);
        } else {
            Toast.makeText(this, "Your Device Don't Support Speech Input", Toast.LENGTH_SHORT).show();
        }
    }


    private void showImageDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Select Image");
        final String[] options = {"Gallery", "Camera"};
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        openGallery();
                        break;
                    case 1:
                        launchCamera();
                        break;
                }
            }
        });
        builder.show();
    }

    public static final int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 42;

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);





        if (intent.resolveActivity(getApplicationContext().getPackageManager()) != null) {
            startActivityForResult(intent, CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);
        }
    }

    private void launchCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);



        if (intent.resolveActivity(getApplicationContext().getPackageManager()) != null) {
            startActivityForResult(intent, CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 10) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                this.binding.mainContent.message.setText(result.get(0));
            }
        } else if (requestCode == CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                try {
                    Uri uri = data.getData();
                    UCrop.Options options = new UCrop.Options();
                    options.setCompressionFormat(Bitmap.CompressFormat.PNG);
                    options.setCompressionQuality(80);
                    UCrop.of(uri, Uri.fromFile(new File(getCacheDir(), "cropped_image.png")))
                            .withAspectRatio(1, 1)
                            .withOptions(options)
                            .start(this);

                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("TAG", "Save Post with resized image failed", e);
                }
            } else {
                Toast.makeText(getApplicationContext(), "Picture wasn't taken!", Toast.LENGTH_SHORT).show();
            }
        } else if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {
            runTextRecognition(UCrop.getOutput(data));
        }
    }

    private void runTextRecognition(Uri imageUri) {
        Bitmap bitmap = null;
        ContentResolver contentResolver = getContentResolver();
        try {
            if (Build.VERSION.SDK_INT < 28) {
                bitmap = MediaStore.Images.Media.getBitmap(contentResolver, imageUri);
            } else {
                ImageDecoder.Source source = ImageDecoder.createSource(contentResolver, imageUri);
                bitmap = ImageDecoder.decodeBitmap(source);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("MYTAG", "ErrorNo: runTextRecognition:" + e);

        }

        onLoading(true);
        InputImage image = InputImage.fromBitmap(bitmap, 90);
        
        TextRecognizer recognizer = TextRecognition.getClient();
        

        recognizer.process(image).addOnSuccessListener(new OnSuccessListener<Text>() {
                    @Override
                    public void onSuccess(Text visionText) {
                        Toast.makeText(getApplicationContext(), "OCR Task completed successfully!", Toast.LENGTH_SHORT).show();

                        List<String> stringList = new ArrayList<>();
                        String recognizedText = visionText.getText();
                        Log.e("TAG", "onSuccess: Recognized text: " + recognizedText);
                        List<Text.TextBlock> blocks = visionText.getTextBlocks();
                        for (Text.TextBlock block : blocks) {
                            List<Text.Line> lines = block.getLines();


                            for (Text.Line line : lines) {
                                List<Text.Element> elements = line.getElements();
                                String line2 = "";
                                for (Text.Element element : elements) {
                                    line2 += " " + element.getText();
                                    Log.e("TAG", "onSuccess: Recognized element: " + element.getText());
                                }
                                stringList.add(line2);

                            }
                        }
                        processTextRecognitionResults(stringList);

                        onLoading(false);
                    }
                })
                .addOnFailureListener(
                        new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                onLoading(false);
                                Log.e("TAG", "OCR Task failed with an exception", e);
                                Toast.makeText(getApplicationContext(), "OCR Task failed!", Toast.LENGTH_SHORT).show();
                            }
                        });
    }


    private String textExtraction;

    private void processTextRecognitionResults(List<String> text) {

        textExtraction = "";
        if (text.size() == 0) {
            textExtraction = String.valueOf(R.string.no_text);
            return;
        }
        Collections.reverse(text);
        for (String s : text) {
            Log.e("MYTAG", "ErrorNo: Strinfsss =>:" + s);
            textExtraction += s;
        }
        this.binding.mainContent.message.setText(textExtraction);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter.getItemCount() == 0) {
            showNoItemView(true);
            List<String> quationsList = new ArrayList<>();
            quationsList.add("What is the value of 6 + 9?");
            quationsList.add("If you have 15 apples and give away 4, how many do you have left?");
            quationsList.add("What is the product of 7 and 3?");
            quationsList.add("If you subtract 8 from 20, what is the result?");
            quationsList.add("If you subtract 8 from 20, what is the result?");
            quationsList.add("What is the quotient of 36 divided by 4?");
            quationsList.add("What is the difference between 24 and 18?");
            quationsList.add("If you have $50 and you spend $27, how much money do you have left?");
            quationsList.add("What is the square root of 100?");
            quationsList.add("If a pizza has 8 slices and you eat 3, how many slices are left?");
            binding.mainContent.recyclerView2.setLayoutManager(new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false));
            binding.mainContent.recyclerView2.setAdapter(new QuationAdapter(quationsList, new QuationAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(String s) {
                    binding.mainContent.message.setText(s);
                }
            }));
        }
    }
}