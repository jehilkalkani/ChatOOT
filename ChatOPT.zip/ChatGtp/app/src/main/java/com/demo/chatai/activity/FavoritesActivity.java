package com.demo.chatai.activity;

import android.content.Context;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.chatai.AdAdmob;
import com.demo.chatai.R;
import com.demo.chatai.adapter.FavoritesAdapter;
import com.demo.chatai.ThisApp;
import com.demo.chatai.room.table.FavoritesEntity;

import java.util.List;

public class FavoritesActivity extends AppCompatActivity {
    private final String TAG = "FavoritesActivity";
    private final Context mContext = this;
    private Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);


        AdAdmob adAdmob = new AdAdmob( this);
        adAdmob.FullscreenAd(this);


        LinearLayout llNoData = findViewById(R.id.llNoData);
        toolbar = findViewById(R.id.toolbar);
        initToolbar();
        List<FavoritesEntity> list = ThisApp.dao().getAllFavoritesEntity();
        if (0 < list.size()) {
            RecyclerView recyclerView = findViewById(R.id.recyclerview);
            recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false));
            recyclerView.setAdapter(new FavoritesAdapter(list, getApplicationContext()));
        } else {
            llNoData.setVisibility(View.VISIBLE);
        }
    }

    private void initToolbar() {
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.getNavigationIcon().setColorFilter(getResources().getColor(R.color.toolbarIconText), PorterDuff.Mode.SRC_ATOP);
        setSupportActionBar(toolbar);
        ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setDisplayHomeAsUpEnabled(true);
        supportActionBar.setHomeButtonEnabled(true);
    }
}