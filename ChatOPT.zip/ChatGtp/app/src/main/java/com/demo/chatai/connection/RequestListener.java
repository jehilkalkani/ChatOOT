package com.demo.chatai.connection;



public class RequestListener<T> {
    public void onFailed(String messages, Object error) {
    }

    public void onFinish() {
    }

    public void onSuccess(T resp) {
    }
}
