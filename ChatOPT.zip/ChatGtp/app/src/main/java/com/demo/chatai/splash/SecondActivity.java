package com.demo.chatai.splash;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.demo.chatai.AdAdmob;
import com.demo.chatai.R;
import com.demo.chatai.activity.ActivityMain;
import com.demo.chatai.adapter.IntroOneAdapter;

public class SecondActivity extends AppCompatActivity {
    Button nextbtn;
    ViewPager view_pager;
    private View conitnuetbtn;
    private TextView skipButton;
    private TextView discriptionText;
    private LinearLayout indicatorLayout;
    TextView[] txtArray;
    int po = 0;

    int page = 0;
    ViewPager.OnPageChangeListener viewListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrollStateChanged(int i) {
        }

        @Override
        public void onPageScrolled(int i, float f, int i2) {
            po++;
        }

        @Override
        public void onPageSelected(int i) {
            page = i;
            indicatorSetBy(i);
            if (i == 0) {
                nextbtn.setVisibility(View.VISIBLE);
                skipButton.setVisibility(View.VISIBLE);
                conitnuetbtn.setVisibility(View.GONE);
                skipButton.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.gray_color_text));
                discriptionText.setText(Html.fromHtml("<b>Sign up here <a href=https://platform.openai.com/playground >link</a></b>"));
                discriptionText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (page == 0) {
                            Intent viewIntent = new Intent("android.intent.action.VIEW", Uri.parse("https://platform.openai.com/playground"));
                            startActivity(viewIntent);
                        }
                    }
                });


                skipButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        NextScreen();
                    }
                });
            } else if (i == 1) {
                nextbtn.setVisibility(View.VISIBLE);
                conitnuetbtn.setVisibility(View.GONE);
                skipButton.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.gray_color_text));
                discriptionText.setText("Now, Click the menu item 'View API keys' And Copy key");
                skipButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        NextScreen();
                    }
                });
            } else if (i == 2) {
                nextbtn.setVisibility(View.GONE);
                conitnuetbtn.setVisibility(View.VISIBLE);
                skipButton.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.white));
                skipButton.setOnClickListener(new View.OnClickListener() {
                    @Override 
                    public void onClick(View view) {
                        NextScreen();
                    }
                });
                discriptionText.setText("Now,Click the menu item 'Manage Account' And Copy Organization ID");
            }
        }
    };

    public void NextScreen() {
        startActivity(new Intent(this, ActivityMain.class));
        finish();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.get_apikey_activity);


        nextbtn = findViewById(R.id.nextbtn);
        view_pager = findViewById(R.id.view_pager);
        conitnuetbtn = findViewById(R.id.conitnuetbtn);
        skipButton = findViewById(R.id.skipButton);
        discriptionText = findViewById(R.id.discriptionText);
        indicatorLayout = findViewById(R.id.indicator_layout);
        discriptionText.setText(Html.fromHtml("<b>Sign up here <a href=https://platform.openai.com/playground >link</a></b>"));


        nextbtn.setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                if (getValue(0) < 3) {
                    view_pager.setCurrentItem(getValue(1), true);
                    return;
                }
                NextScreen();
            }
        });
        view_pager.setAdapter(new IntroOneAdapter(this));
        indicatorSetBy(0);
        view_pager.addOnPageChangeListener(this.viewListener);
        conitnuetbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        NextScreen();
                    }
                }, 1000L);
            }
        });
    }

    public int getValue(int i) {
        return view_pager.getCurrentItem() + i;
    }

    public void indicatorSetBy(int i) {
        txtArray = new TextView[3];
        indicatorLayout.removeAllViews();
        int counter = 0;
        while (true) {
            TextView[] textViewArr = this.txtArray;
            if (counter >= textViewArr.length) {
                break;
            }
            textViewArr[counter] = new TextView(this);
            this.txtArray[counter].setText(Html.fromHtml("&#8226"));
            this.txtArray[counter].setTextSize(35.0f);
            if (Build.VERSION.SDK_INT >= 23) {
                this.txtArray[counter].setTextColor(getResources().getColor(R.color.gray_color_text, getApplicationContext().getTheme()));
            }
            indicatorLayout.addView(this.txtArray[counter]);
            counter++;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            this.txtArray[i].setTextColor(getResources().getColor(R.color.primary, getApplicationContext().getTheme()));
        }
    }

}
