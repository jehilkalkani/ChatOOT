package com.demo.chatai.utils;

import com.demo.chatai.AppConfig;


public class AppConfigExt {
    public static AppConfig.General general = new AppConfig.General();


}
