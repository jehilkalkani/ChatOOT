package com.demo.chatai;

import android.content.Context;
import android.util.AttributeSet;
import android.util.TypedValue;

public class CustomEditText extends androidx.appcompat.widget.AppCompatEditText {
    private int maxLines = 5;
    private int minLines = 1;

    public CustomEditText(Context context) {
        super(context);
    }

    public CustomEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onTextChanged(CharSequence text, int start, int lengthBefore, int lengthAfter) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter);
        int lines = getLineCount();
        if (lines > maxLines) {
            setMaxLines(lines);
        } else if (lines < minLines) {
            setMinLines(lines);
        }
    }

    public void setMaxLines(int maxLines) {
        this.maxLines = maxLines;
        super.setMaxLines(maxLines);
    }

    public void setMinLines(int minLines) {
        this.minLines = minLines;
        super.setMinLines(minLines);
    }
}