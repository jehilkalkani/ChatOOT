package com.demo.chatai.room;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.demo.chatai.room.table.ApiKeyEntity;
import com.demo.chatai.room.table.ChatEntity;
import com.demo.chatai.room.table.ConversationEntity;
import com.demo.chatai.R;
import com.demo.chatai.room.table.FavoritesEntity;

@Database(entities = {ApiKeyEntity.class, ChatEntity.class, ConversationEntity.class, FavoritesEntity.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase INSTANCE;

    public abstract DAO get();

    public static AppDatabase getDb(Context context) {
        if (INSTANCE == null) {
            INSTANCE = (AppDatabase) Room.databaseBuilder(context, AppDatabase.class, context.getString(R.string.app_name) + "_database").allowMainThreadQueries().fallbackToDestructiveMigration().build();
        }
        return INSTANCE;
    }

    public static void destroyInstance() {
        INSTANCE = null;
    }
}
