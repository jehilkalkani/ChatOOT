package com.demo.chatai.model;

import java.io.Serializable;

public class Chat implements Serializable {
    public String role = "";
    public String content = "";
}