package com.demo.chatai.adapter;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.chatai.R;
import com.demo.chatai.ThisApp;
import com.demo.chatai.room.table.ChatEntity;
import com.demo.chatai.room.table.FavoritesEntity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class AdapterChat extends RecyclerView.Adapter<AdapterChat.ChatViewHolder> {
    private OnItemClickListener mOnItemClickListener;
    private Context ctx;
    private List<ChatEntity> items;
    private boolean loading;
    private RecyclerView recyclerView;
    private TextToSpeech mTTS;
    private ImageView tts_button;
    private String mLastDate = "";

    public interface OnItemClickListener {
        void onItemClick(View view, ChatEntity obj, int position);
    }

    public AdapterChat(Context context, RecyclerView view, List<ChatEntity> items) {
        new ArrayList();
        this.items = items;
        this.ctx = context;
        this.recyclerView = view;
        mTTS = new TextToSpeech(ctx, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    mTTS.setLanguage(Locale.US);
                }
            }
        });
    }

    @NonNull
    @Override
    public AdapterChat.ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        int layout = viewType == 0 ? R.layout.item_chat : R.layout.item_loading;
        View itemView = inflater.inflate(layout, parent, false);
        tts_button = itemView.findViewById(R.id.tts_button);
        return new ChatViewHolder(itemView, tts_button);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterChat.ChatViewHolder holder, @SuppressLint("RecyclerView") int position) {
        ChatEntity chatEntity = items.get(position);
        holder.lytparent.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (mOnItemClickListener != null) {
                    mOnItemClickListener.onItemClick(v, chatEntity, position);
                }
                return true;
            }
        });
        holder.bind(chatEntity, mTTS, position);
    }

    public class ChatViewHolder extends RecyclerView.ViewHolder {
        private TextView mMessageTextView;
        private TextView date;
        private TextView time;
        private ImageView mTTSButton;
        private ImageView mCopyTextView;
        private ImageView mShareTextView;
        private ImageView favorites;
        private ConstraintLayout lytparent;

        public ChatViewHolder(View itemView, ImageView button) {
            super(itemView);
            mCopyTextView = itemView.findViewById(R.id.copy);
            mShareTextView = itemView.findViewById(R.id.share);
            mMessageTextView = itemView.findViewById(R.id.message);
            date = itemView.findViewById(R.id.text_gchat_date_other);
            time = itemView.findViewById(R.id.text_gchat_timestamp_other);
            lytparent = itemView.findViewById(R.id.lyt_parent);
            favorites = itemView.findViewById(R.id.favorites);

            mTTSButton = button;
            mTTS.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                    Toast.makeText(ctx, "onStart", Toast.LENGTH_LONG).show();
                    ;
                    Log.e("MYTAG", "ErrorNo: run: onStart");
                } 

                @Override
                public void onError(String utteranceId) {
                    Toast.makeText(ctx, "onError", Toast.LENGTH_LONG).show();
                    ;
                } 

                @Override
                public void onDone(String utteranceId) {
                    Toast.makeText(ctx, "onDone", Toast.LENGTH_LONG).show();
                }
            });
        }

        public void bind(ChatEntity chatEntity, TextToSpeech mTTS, int position) {
            Log.e("MYTAG", "ErrorNo: :" + chatEntity.message);
            Log.e("MYTAG", "ErrorNo: :" + mMessageTextView);

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");

            String dateString = dateFormat.format(new Date(chatEntity.getId()));
            String timeString = timeFormat.format(new Date(chatEntity.getId()));

            if (!TextUtils.equals(dateString, mLastDate)) {
                date.setVisibility(View.VISIBLE);
                date.setText(dateString);
                mLastDate = dateString;
            } else {
                date.setVisibility(View.GONE);
            }
            time.setText(timeString);
            if (chatEntity.me) {
                mTTSButton.setVisibility(View.GONE);
            } else {
                if (ThisApp.dao().isFavoritesFound(chatEntity.getId()) != 0) {
                    favorites.setImageResource(R.drawable.ic_baseline_star_rate_24);
                } else {
                    favorites.setImageResource(R.drawable.ic_baseline_star_outline_24);
                }

                mTTSButton.setVisibility(View.VISIBLE);
                mTTSButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String text = chatEntity.getMessage();
                        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

                    }
                });
                mCopyTextView.setOnClickListener(v -> {
                    ClipboardManager clipboard = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("label", chatEntity.message);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(ctx, "copy ", Toast.LENGTH_SHORT).show();
                });
                mShareTextView.setOnClickListener(v -> {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_TEXT, chatEntity.message);
                    ctx.startActivity(Intent.createChooser(shareIntent, "Share this app with"));
                });
                favorites.setOnClickListener(v -> {
                    if (ThisApp.dao().isFavoritesFound(chatEntity.getId()) != 0) {
                        ThisApp.dao().deleteFavoritesEntity(chatEntity.getId());
                        favorites.setImageResource(R.drawable.ic_baseline_star_outline_24);
                    } else {
                        ChatEntity QuationEntity = items.get(position - 1);
                        ThisApp.dao().insertFavoritesEntity(new FavoritesEntity(chatEntity.message, QuationEntity.message, chatEntity.getId()));
                        favorites.setImageResource(R.drawable.ic_baseline_star_rate_24);
                    }
                });
            }
            if (chatEntity.new_chat) {
                setTextWithAnimation(chatEntity.getId(), mMessageTextView, chatEntity.message, 1);
            } else {

                mMessageTextView.setText(chatEntity.message);
            }


        }
    }

    private void setTextWithAnimation(final Long id, final TextView textView, final String text, final int index) {
        try {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    setAnimation(index, text, textView, id);
                }
            }, 25L);
        } catch (Exception unused) {
            textView.setText(text);
        }
    }

    public void setAnimation(int index, String text, TextView textView, Long id) {
        if (index < text.length()) {
            textView.setText(text.substring(0, index));
            setTextWithAnimation(id, textView, text, index + 1);
            return;
        }
        for (ChatEntity chatEntity : this.items) {
            if (Objects.equals(chatEntity.getId(), id)) {
                chatEntity.new_chat = false;
                return;
            }
        }
    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }

    @Override
    public int getItemViewType(int position) {
        return this.items.get(position).me ? 1 : 0;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }

    public void setItems(List<ChatEntity> items) {
        this.items = items;
        notifyDataSetChanged();
        this.recyclerView.scrollToPosition(getItemCount() - 1);
    }

    public void removeItem(int position) {
        try {
            if (items.size() != 0) {
                this.items.remove(position);
                notifyDataSetChanged();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("MYTAG", "ErrorNo: removeItem:" + e);
        }
    }

    public void resetListData() {
        this.items = new ArrayList();
        notifyDataSetChanged();
    }

    public void addData(ChatEntity item) {
        this.items.add(item);

        this.recyclerView.smoothScrollToPosition(getItemCount() - 1);
    }

    public void removeLast() {
        this.items.remove(getItemCount() - 1);
        notifyDataSetChanged();
    }
}
