package com.demo.chatai.activity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AnimationUtils;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.demo.chatai.R;
import com.demo.chatai.databinding.ActivitySplashBinding;
import com.demo.chatai.utils.Tools;

public class ActivitySplash extends AppCompatActivity {
    static boolean active = false;
    private AlertDialog alertDialog;
    private ActivitySplashBinding binding;

    public static void navigate(Activity activity) {
        activity.startActivity(new Intent(activity, ActivitySplash.class));
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivitySplashBinding inflate = ActivitySplashBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView(inflate.getRoot());
        this.binding.title.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.push_down_in));
        this.binding.shimmer.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.push_up_in));
        new Handler().postDelayed(new Runnable() {
            @Override
            public final void run() {
                ActivitySplash.this.m81lambda$onCreate$1$comappchattyaiactivityActivitySplash();
            }
        }, 2000L);
        Tools.fullScreen(this);
    }

    private void lambda$onCreate$0() {
        if (active) {
            dialogFailedRemoteConfig(getString(R.string.message_failed_config));
        }
    }

    public void dialogFailedRemoteConfig(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Failed");
        builder.setMessage(message);
        builder.setCancelable(false);
        builder.setPositiveButton(R.string.RETRY, new DialogInterface.OnClickListener() {
            @Override
            public final void onClick(DialogInterface dialogInterface, int i) {
                ActivitySplash.this.m80xc0cf576f(dialogInterface, i);
            }
        });
        this.alertDialog = builder.show();
    }

    public void m80xc0cf576f(DialogInterface dialogInterface, int i) {
        dialogInterface.dismiss();

    }

    public void m81lambda$onCreate$1$comappchattyaiactivityActivitySplash() {
        AlertDialog alertDialog = this.alertDialog;
        if (alertDialog != null && alertDialog.isShowing()) {
            this.alertDialog.dismiss();
        }
        startActivity(new Intent(this, ActivityMain.class));
        finish();
    }

    @Override
    public void onStart() {
        super.onStart();
        active = true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        active = false;
    }
}
