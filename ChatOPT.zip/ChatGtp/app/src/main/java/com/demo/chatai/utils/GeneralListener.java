package com.demo.chatai.utils;


public class GeneralListener<T> {
    public void onCancel() {
    }

    public void onFinish(T resp) {
    }
}
