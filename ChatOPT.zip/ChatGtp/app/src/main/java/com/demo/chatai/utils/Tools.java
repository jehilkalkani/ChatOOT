package com.demo.chatai.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.text.Html;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.URLUtil;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.browser.customtabs.CustomTabColorSchemeParams;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.view.ViewCompat;

import com.demo.chatai.AppConfig;
import com.demo.chatai.R;
import com.demo.chatai.activity.ActivitySplash;
import com.demo.chatai.ThisApp;
import com.demo.chatai.room.table.ApiKeyEntity;
import com.demo.chatai.databinding.DialogApiKeyBinding;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Tools {

    public static void RTLMode(Window window) {
    }

    public static void darkNavigation(Activity activity) {
        if (Build.VERSION.SDK_INT >= 26) {
            activity.getWindow().setNavigationBarColor(ViewCompat.MEASURED_STATE_MASK);
            activity.getWindow().setStatusBarColor(ViewCompat.MEASURED_STATE_MASK);
            activity.getWindow().getDecorView().setSystemUiVisibility(0);
        }
    }


    public static void fullScreen(Activity activity) {
        activity.getWindow().setFlags(1024, 1024);
    }

    public static boolean isConnect(Context context) {
        try {
            NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
            if (activeNetworkInfo != null) {
                if (activeNetworkInfo.isConnected()) {
                    return true;
                }
                return activeNetworkInfo.isConnectedOrConnecting();
            }
        } catch (Exception unused) {
        }
        return false;
    }

    public static int getStatusBarHeight(Context context) {
        int identifier = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (identifier > 0) {
            return context.getResources().getDimensionPixelSize(identifier);
        }
        return 0;
    }

    public static String getFormattedDateSimple(Long dateTime) {
        return new SimpleDateFormat("dd MMM yy hh:mm").format(new Date(dateTime.longValue()));
    }

    public static void rateAction(Activity activity) {
        String str = AppConfig.general.non_playstore_market_android;
        if (TextUtils.isEmpty(str)) {
            activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=com.app.chattyai")));
        } else {
            directLinkCustomTab(activity, str);
        }
    }

    public static int getGridSpanCount(Activity activity) {
        Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics);
        return Math.round(displayMetrics.widthPixels / activity.getResources().getDimension(R.dimen.listing_width));
    }

    public static void directLinkCustomTab(final Activity activity, String url) {
        if (!URLUtil.isValidUrl(url)) {
            Toast.makeText(activity, "Ops, Cannot open url", Toast.LENGTH_LONG).show();
        } else if (!AppConfig.general.open_link_in_app) {
            activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        } else {
            int color = ResourcesCompat.getColor(activity.getResources(), R.color.primary, null);
            int color2 = ResourcesCompat.getColor(activity.getResources(), R.color.accent, null);
            CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
            builder.setDefaultColorSchemeParams(new CustomTabColorSchemeParams.Builder().setToolbarColor(color).setSecondaryToolbarColor(color2).build());
            builder.setShowTitle(true);
            builder.setUrlBarHidingEnabled(true);
            CustomTabsHelper.openCustomTab(activity, builder.build(), Uri.parse(url), new CustomTabsHelper.CustomTabFallback() {
                @Override
                public final void openUri(Activity activity2, Uri uri) {
                    Tools.lambda$directLinkCustomTab$0(activity, activity2, uri);
                }
            });
        }
    }


    public static void lambda$directLinkCustomTab$0(Activity activity, Activity activity2, Uri uri) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.putExtra("android.intent.action.VIEW", uri);
        activity.startActivity(intent);
    }

    public static void hideKeyboard(Activity activity) {
        View currentFocus = activity.getCurrentFocus();
        if (currentFocus != null) {
            ((InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
    }

    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static void aboutAction(Activity activity) {






        String url = "http://google.com";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        activity.startActivity(i);
    }

    public static void applyTheme(boolean dark) {
        if (dark) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    public static void changeOverflowMenuIconColor(Toolbar toolbar, int color) {
        try {
            Drawable overflowIcon = toolbar.getOverflowIcon();
            overflowIcon.mutate();
            overflowIcon.setColorFilter(color, PorterDuff.Mode.SRC_ATOP);
        } catch (Exception unused) {
        }
    }

    public static void copyToClipBoard(Context context, String coupon) {
        ((ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText(context.getString(R.string.app_name), coupon));
        Toast.makeText(context, (int) R.string.tex_copied, Toast.LENGTH_SHORT).show();
    }

    public static DisplayMetrics getDeviceMetrics(Context context) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics;
    }

    public static void showToastCustom(Context context, int resId) {
        Toast.makeText(context, resId, Toast.LENGTH_SHORT).show();
    }

    public static void showToastCustom(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    public static void showDialogApiKey(Activity activity, ApiKeyEntity entity, final GeneralListener<ApiKeyEntity> listener) {
        final Dialog dialog = new Dialog(activity);
        boolean z = entity == null;
        final DialogApiKeyBinding inflate = DialogApiKeyBinding.inflate(LayoutInflater.from(activity));
        dialog.setContentView(inflate.getRoot());
        dialog.setCancelable(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        WindowManager.LayoutParams attributes = dialog.getWindow().getAttributes();
        double d = getDeviceMetrics(activity).widthPixels;
        Double.isNaN(d);
        attributes.width = (int) (d * 0.85d);
        RTLMode(dialog.getWindow());
        inflate.title.setText(z ? "Add API Key" : "Edit API Key");
        if (z) {
            entity = new ApiKeyEntity();
            entity.setId(Long.valueOf(System.currentTimeMillis()));
            inflate.btDelete.setVisibility(View.GONE);
        } else {
            inflate.name.setText(entity.getName());
            inflate.apiKey.setText(entity.getKey());
        }
        final ApiKeyEntity apiKeyEntity = entity;
        inflate.btDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                Tools.lambda$showDialogApiKey$4(apiKeyEntity, activity, listener, dialog, view);
            }
        });
        inflate.btPaste.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                Tools.lambda$showDialogApiKey$5(activity, inflate, view);
            }
        });
        inflate.buttonGetApiKey.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                Tools.directLinkCustomTab(activity, AppConfig.general.link_get_api_key);
            }
        });
        inflate.buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                Tools.lambda$showDialogApiKey$7(inflate, apiKeyEntity, activity, listener, dialog, view);
            }
        });
        dialog.show();
    }


    public static void lambda$showDialogApiKey$4(ApiKeyEntity apiKeyEntity, Activity activity, GeneralListener generalListener, Dialog dialog, View view) {
        if (apiKeyEntity.getSelected().booleanValue()) {
            showToastCustom(activity, "Cannot delete selected API Keye");
            return;
        }
        ThisApp.dao().deleteApiKey(apiKeyEntity.getId().longValue());
        if (generalListener != null) {
            generalListener.onFinish(apiKeyEntity);
        }
        showToastCustom(activity, "API key deleted successfully!");
        dialog.dismiss();
    }


    public static void lambda$showDialogApiKey$5(Activity activity, DialogApiKeyBinding dialogApiKeyBinding, View view) {
        String clipBoardText = getClipBoardText(activity);
        if (TextUtils.isEmpty(clipBoardText)) {
            return;
        }
        dialogApiKeyBinding.apiKey.setText(clipBoardText);
    }


    public static void lambda$showDialogApiKey$7(DialogApiKeyBinding dialogApiKeyBinding, ApiKeyEntity apiKeyEntity, Activity activity, GeneralListener generalListener, Dialog dialog, View view) {

      try {
          String trim = dialogApiKeyBinding.name.getText().toString().trim();
          String trim2 = dialogApiKeyBinding.apiKey.getText().toString().trim();
          if (TextUtils.isEmpty(trim)) {
              trim = "API Key";
          }
          apiKeyEntity.setName(trim);
          apiKeyEntity.setKey(trim2);
          if (TextUtils.isEmpty(trim2)) {
              showToastCustom(activity, "Please fill API key");
              return;
          }
          if (ThisApp.dao().getApiKeyEnabledCount().intValue() <= 0) {
              apiKeyEntity.setSelected(true);
          }
          List<ApiKeyEntity> allApiKey2 = ThisApp.dao().getAllApiKey();
          if(!allApiKey2.isEmpty() && allApiKey2!=null){
              for (int i = 0; i < allApiKey2.size(); i++) {
                  if (!allApiKey2.get(i).key.equals(apiKeyEntity.key)) {
                      Toast.makeText(activity.getApplication(), "API key Already Exists", Toast.LENGTH_LONG);
                      break;
                  }
              }
          }
          ThisApp.dao().insertApiKey(apiKeyEntity);
          if (generalListener != null) {
              generalListener.onFinish(apiKeyEntity);
          }
          showToastCustom(activity, "API key added successfully!");
          dialog.dismiss();
      }catch (Exception e){
          e.printStackTrace();
          e.printStackTrace();
          Log.e("MYTAG", "ErrorNo: lambda$showDialogApiKey$7:" +e);
          Toast.makeText(activity.getApplication(), "Something Error", Toast.LENGTH_LONG);
      }

    }

    public static String hideApiKey(String input, int max, String rep) {
        if (input.length() <= max) {
            return input;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < input.length() - max; i++) {
            sb.append(rep);
        }
        return input.substring(0, max) + ((Object) sb);
    }

    public static String getClipBoardText(Context context) {
        try {
            return ((ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE)).getPrimaryClip().getItemAt(0).getText().toString();
        } catch (Exception unused) {
            return null;
        }
    }
}
