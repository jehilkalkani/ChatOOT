package com.demo.chatai.connection;

import com.demo.chatai.connection.response.ResponseChat;
import com.demo.chatai.model.Param;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;


public interface API {







    public static final String AGENT = "User-Agent: ChattyAI";
    public static final String CACHE = "Cache-Control: max-age=0";

    @Headers({CACHE, AGENT})
    @POST
    Call<ResponseChat> sendChat(@Url String url, @Body Param param, @Header("Authorization") String auth);


}
