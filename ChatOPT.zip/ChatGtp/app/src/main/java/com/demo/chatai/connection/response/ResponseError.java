package com.demo.chatai.connection.response;

import java.io.Serializable;

public class ResponseError implements Serializable {
    public Error error = new Error();

    
    public class Error {
        public String message = "";
        public String type = "";
        public String param = "";
        public String code = "";

        public Error() {
        }
    }
}
