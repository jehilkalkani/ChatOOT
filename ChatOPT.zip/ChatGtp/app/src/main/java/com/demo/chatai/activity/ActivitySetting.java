package com.demo.chatai.activity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.demo.chatai.AdAdmob;
import com.demo.chatai.AppConfig;
import com.demo.chatai.BuildConfig;
import com.demo.chatai.R;
import com.demo.chatai.ThisApp;
import com.demo.chatai.databinding.ActivitySettingBinding;
import com.demo.chatai.utils.Tools;
public class ActivitySetting extends AppCompatActivity {
    public ActivitySettingBinding binding;
    public static void navigate(Activity activity) {
        activity.startActivity(new Intent(activity, ActivitySetting.class));
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivitySettingBinding inflate = ActivitySettingBinding.inflate(getLayoutInflater());


        AdAdmob adAdmob = new AdAdmob( this);
        adAdmob.BannerAd(binding.banner, this);
        adAdmob.FullscreenAd_Counter(this);



        this.binding = inflate;
        setContentView(inflate.getRoot());
        initToolbar();
        initComponent();
        Tools.RTLMode(getWindow());
    }
    private void initToolbar() {
        this.binding.toolbar.setNavigationIcon(R.drawable.ic_back);
        this.binding.toolbar.getNavigationIcon().setColorFilter(getResources().getColor(R.color.toolbarIconText), PorterDuff.Mode.SRC_ATOP);
        setSupportActionBar(this.binding.toolbar);
        ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setDisplayHomeAsUpEnabled(true);
        supportActionBar.setHomeButtonEnabled(true);
    }
    private void initComponent() {
        this.binding.actionApiKey.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                Tools.showDialogApiKey(ActivitySetting.this, null, null);
            }
        });

        this.binding.actionPrivacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                Tools.directLinkCustomTab(ActivitySetting.this, "https://google.com");
            }
        });
        this.binding.actionAboutApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public final void onClick(View view) {
                Tools.aboutAction(ActivitySetting.this);
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 16908332) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
