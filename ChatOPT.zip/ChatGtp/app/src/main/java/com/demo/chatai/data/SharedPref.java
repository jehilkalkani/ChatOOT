package com.demo.chatai.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;


public class SharedPref {
    private static String default_ringtone_url = "content://settings/system/notification_sound";
    private static SharedPref mInstance;
    private Context context;
    private SharedPreferences prefs;
    private SharedPreferences sharedPreferences;

    public static synchronized SharedPref get() {
        SharedPref sharedPref;
        synchronized (SharedPref.class) {
            sharedPref = mInstance;
        }
        return sharedPref;
    }

    public SharedPref(Context context) {
        mInstance = this;
        this.context = context;
        this.sharedPreferences = context.getSharedPreferences("MAIN_PREF", 0);
        this.prefs = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public void setDarkTheme(boolean flag) {
        this.sharedPreferences.edit().putBoolean("DARK_THEME", flag).apply();
    }

    public boolean isDarkTheme() {
        return this.sharedPreferences.getBoolean("DARK_THEME", false);
    }

    public void setRandomKey(boolean flag) {
        this.sharedPreferences.edit().putBoolean("RANDOM_KEY", flag).apply();
    }

    public boolean isRandomKey() {
        return this.sharedPreferences.getBoolean("RANDOM_KEY", false);
    }

    public void setFcmRegId(String fcmRegId) {
        this.sharedPreferences.edit().putString("FCM_PREF_KEY", fcmRegId).apply();
    }

    public String getFcmRegId() {
        return this.sharedPreferences.getString("FCM_PREF_KEY", null);
    }

    public boolean isFcmRegIdEmpty() {
        return TextUtils.isEmpty(getFcmRegId());
    }

    public void setSubscibeNotif(boolean value) {
        this.sharedPreferences.edit().putBoolean("SUBSCRIBE_NOTIF", value).apply();
    }

    public boolean isSubscibeNotif() {
        return this.sharedPreferences.getBoolean("SUBSCRIBE_NOTIF", false);
    }

    public void setFirstLaunch(boolean flag) {
        this.sharedPreferences.edit().putBoolean("FIRST_LAUNCH", flag).apply();
    }

    public boolean isFirstLaunch() {
        return this.sharedPreferences.getBoolean("FIRST_LAUNCH", true);
    }

    public void setPushNotification(boolean value) {
        this.sharedPreferences.edit().putBoolean("SETTINGS_PUSH_NOTIF", value).apply();
    }

    public boolean getPushNotification() {
        return this.sharedPreferences.getBoolean("SETTINGS_PUSH_NOTIF", true);
    }

    public String getRingtone() {
        return this.sharedPreferences.getString("SETTINGS_RINGTONE", default_ringtone_url);
    }

    public String getAppStatus() {
        return this.sharedPreferences.getString("APP_STATUS", "");
    }

    public void setAppStatus(String status) {
        this.sharedPreferences.edit().putString("APP_STATUS", status).apply();
    }

    public void setIntersCounter(int counter) {
        this.sharedPreferences.edit().putInt("INTERS_COUNT", counter).apply();
    }

    public int getIntersCounter() {
        return this.sharedPreferences.getInt("INTERS_COUNT", 0);
    }

    public void clearIntersCounter() {
        this.sharedPreferences.edit().putInt("INTERS_COUNT", 0).apply();
    }

    public void setNeverAskAgain(String key, boolean value) {
        this.sharedPreferences.edit().putBoolean(key, value).apply();
    }

    public boolean getNeverAskAgain(String key) {
        return this.sharedPreferences.getBoolean(key, false);
    }
}
