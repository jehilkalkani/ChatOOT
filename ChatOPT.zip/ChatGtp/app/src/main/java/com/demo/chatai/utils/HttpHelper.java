package com.demo.chatai.utils;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

public class HttpHelper {
    private static final String TAG = "HttpHelper";
    private Map<String, String> headers;
    private String urlString;


    public interface OnResponseListener {
        void onError(String error);

        void onSuccess(String response);
    }

    public HttpHelper(String url) {
        this.urlString = url;
    }

    public HttpHelper() {
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public void setUrlString(String urlString) {
        this.urlString = urlString;
    }

    public void get(OnResponseListener listener) {
        new HttpRequestTask(listener).execute(new String[0]);
    }

    public void get(Map<String, String> params, OnResponseListener listener) {
        String paramsToString = paramsToString(params);
        setUrlString(this.urlString + "?" + paramsToString);
        new HttpRequestTask(listener).execute(new String[0]);
    }

    public void post(Map<String, String> params, OnResponseListener listener) {
        new HttpRequestTask(listener).execute("POST", paramsToString(params));
    }

    public void postJson(String json, OnResponseListener listener) {
        new HttpRequestTask(listener).execute("POST", json);
    }


    private class HttpRequestTask extends AsyncTask<String, Void, String> {
        private final OnResponseListener listener;

        public HttpRequestTask(OnResponseListener listener) {
            this.listener = listener;
        }


        @Override
        public String doInBackground(String... params) {
            String str = params[0];
            String str2 = params.length > 1 ? params[1] : null;
            try {
                URL url = new URL(HttpHelper.this.urlString);
                Log.d(HttpHelper.TAG, "Request: " + str + " " + HttpHelper.this.urlString);
                StringBuilder sb = new StringBuilder("Request Body: ");
                sb.append(str2);
                Log.d(HttpHelper.TAG, sb.toString());
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod(str);
                if (HttpHelper.this.headers != null) {
                    for (Map.Entry entry : HttpHelper.this.headers.entrySet()) {
                        httpURLConnection.setRequestProperty((String) entry.getKey(), (String) entry.getValue());
                    }
                }
                if (str.equals("POST")) {
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setFixedLengthStreamingMode(str2.getBytes().length);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    outputStream.write(str2.getBytes());
                    outputStream.flush();
                    outputStream.close();
                }
                int responseCode = httpURLConnection.getResponseCode();
                if (responseCode != 200) {
                    return "HTTP error code: " + responseCode;
                }
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                StringBuilder sb2 = new StringBuilder();
                while (true) {
                    String readLine = bufferedReader.readLine();
                    if (readLine != null) {
                        sb2.append(readLine);
                    } else {
                        bufferedReader.close();
                        Log.d(HttpHelper.TAG, "Response Body: " + sb2.toString());
                        return sb2.toString();
                    }
                }
            } catch (IOException e) {
                Log.e(HttpHelper.TAG, "Error executing HTTP request: " + e.getMessage());
                return "Error executing HTTP request: " + e.getMessage();
            }
        }


        @Override
        public void onPostExecute(String result) {
            if (result.startsWith("HTTP error")) {
                this.listener.onError(result);
            } else {
                this.listener.onSuccess(result);
            }
        }
    }

    private static String paramsToString(Map<String, String> params) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> entry : params.entrySet()) {
            sb.append(entry.getKey());
            sb.append("=");
            sb.append(entry.getValue());
            sb.append("&");
        }
        return sb.substring(0, sb.length() - 1);
    }
}
