package com.demo.chatai.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.demo.chatai.ThisApp;
import com.demo.chatai.R;
import com.demo.chatai.room.table.ApiKeyEntity;
import com.demo.chatai.utils.Tools;
import com.demo.chatai.databinding.ItemApiKeyBinding;

import java.util.ArrayList;
import java.util.List;


public class AdapterApiKey extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context ctx;
    private List<ApiKeyEntity> items;
    private OnItemClickListener mOnItemClickListener;

    public enum ActionType {
        ITEM,
        EDIT
    }

    public interface OnItemClickListener {
        void onItemClick(View view, ApiKeyEntity obj, int position, ActionType actionType);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mOnItemClickListener = mItemClickListener;
    }

    public AdapterApiKey(Context context, RecyclerView view, List<ApiKeyEntity> items) {
        new ArrayList();
        this.items = items;
        this.ctx = context;
    }


    public class OriginalViewHolder extends RecyclerView.ViewHolder {
        ItemApiKeyBinding binding;

        public OriginalViewHolder(ItemApiKeyBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new OriginalViewHolder(ItemApiKeyBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof OriginalViewHolder) {
            final ApiKeyEntity apiKeyEntity = this.items.get(position);
            OriginalViewHolder originalViewHolder = (OriginalViewHolder) holder;
            originalViewHolder.binding.name.setText(apiKeyEntity.getName());
            originalViewHolder.binding.key.setText(Tools.hideApiKey(apiKeyEntity.getKey(), 10, "*"));
            if (ThisApp.pref().isRandomKey() || apiKeyEntity.getSelected().booleanValue()) {
                originalViewHolder.binding.radioSelected.setImageResource(R.drawable.ic_radio_button_checked);
            } else {
                originalViewHolder.binding.radioSelected.setImageResource(R.drawable.ic_radio_button_unchecked);
            }
            originalViewHolder.binding.lytParent.setOnClickListener(new View.OnClickListener() {
                @Override
                public final void onClick(View view) {
                    AdapterApiKey.this.m83lambda$onBindViewHolder$0$comappchattyaiadapterAdapterApiKey(apiKeyEntity, position, view);
                }
            });
            originalViewHolder.binding.btEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public final void onClick(View view) {
                    AdapterApiKey.this.m84lambda$onBindViewHolder$1$comappchattyaiadapterAdapterApiKey(apiKeyEntity, position, view);
                }
            });
        }
    }


    public void m83lambda$onBindViewHolder$0$comappchattyaiadapterAdapterApiKey(ApiKeyEntity apiKeyEntity, int i, View view) {
        OnItemClickListener onItemClickListener = this.mOnItemClickListener;
        if (onItemClickListener != null) {
            onItemClickListener.onItemClick(view, apiKeyEntity, i, ActionType.ITEM);
        }
    }


    public void m84lambda$onBindViewHolder$1$comappchattyaiadapterAdapterApiKey(ApiKeyEntity apiKeyEntity, int i, View view) {
        OnItemClickListener onItemClickListener = this.mOnItemClickListener;
        if (onItemClickListener != null) {
            onItemClickListener.onItemClick(view, apiKeyEntity, i, ActionType.EDIT);
        }
    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }

    public void removeItem(int position) {
        this.items.remove(position);
        notifyDataSetChanged();
    }

    public void addData(ApiKeyEntity item) {
        this.items.add(0, item);
        notifyItemInserted(0);
    }

    public void refreshSelected() {
        for (ApiKeyEntity apiKeyEntity : this.items) {
            apiKeyEntity.setSelected(false);
        }
        notifyDataSetChanged();
    }

    public void insertData(List<ApiKeyEntity> items) {
        int itemCount = getItemCount();
        int size = items.size();
        this.items.addAll(items);
        notifyItemRangeInserted(itemCount, size);
    }

    public void setItems(List<ApiKeyEntity> items) {
        this.items = items;
        notifyDataSetChanged();
    }
}
