package com.demo.chatai;
import com.demo.chatai.utils.AppConfigExt;

import java.io.Serializable;
public class AppConfig extends AppConfigExt implements Serializable {
    public static final String strIntentChat = "chatData";
    public static class General {
        public String api_url = "https://api.openai.com/v1/chat/completions";
        public String param_open_ai_model = "gpt-3.5-turbo";
        public Double param_temperature = Double.valueOf(0.9d);
        public Integer param_max_tokens = Integer.valueOf((int) 150);
        public String link_get_api_key = "https://platform.openai.com/account/api-keys";
        public String link_quota_usage = "https://platform.openai.com/account/usage";
        public String link_upgrade_account = "https://platform.openai.com/account/billing/overview";
        public String role_human = "user";
        public String role_ai = "assistant";
        public String non_playstore_market_android = "";
        public boolean open_link_in_app = true;
    }
}
