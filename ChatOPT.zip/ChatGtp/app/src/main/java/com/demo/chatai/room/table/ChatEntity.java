package com.demo.chatai.room.table;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.demo.chatai.AppConfig;
import com.demo.chatai.model.Chat;

import java.io.Serializable;


@Entity(tableName = "chat")
public class ChatEntity implements Serializable {
        @ColumnInfo(name = "conversation")
    public Long conversation;

    @ColumnInfo(name = "created_at")
    public Long created_at;
    @PrimaryKey()
    @NonNull
    public Long id;

    @ColumnInfo(name = "message")
    public String message;

    @ColumnInfo(name = "me")
    public Boolean me = true;
    public ChatEntity() {
    }
    public boolean new_chat = false;
    public ChatEntity(String message, Long conversation) {
        setId(System.currentTimeMillis());
        setMe(true);
        setConversation(conversation);
        setMessage(message);
        setCreated_at(getId());
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getConversation() {
        return this.conversation;
    }

    public void setConversation(Long conversation) {
        this.conversation = conversation;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Boolean getMe() {
        return this.me;
    }

    public void setMe(Boolean me) {
        this.me = me;
    }

    public Long getCreated_at() {
        return this.created_at;
    }

    public void setCreated_at(Long created_at) {
        this.created_at = created_at;
    }

    public Chat getChat() {
        Chat chat = new Chat();
        chat.role = this.me.booleanValue() ? AppConfig.general.role_human : AppConfig.general.role_ai;
        chat.content = this.message;
        return chat;
    }































































}
