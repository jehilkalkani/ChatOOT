package com.demo.chatai.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;



public class Param implements Serializable {
    public double frequency_penalty;
    public int max_tokens;
    public List<Chat> messages = new ArrayList();
    public String model;
    public double presence_penalty;
    public double temperature;
    public int top_p;
}